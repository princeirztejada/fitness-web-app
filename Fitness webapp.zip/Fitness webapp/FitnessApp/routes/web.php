<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'PagesController@index');

// Route::resource('user','UserController');
Route::get('/myProfile', 'UserController@myProfile');
Route::get('/user', 'UserController@index');
Route::post('/user', 'UserController@store');
Route::patch('/user', 'UserController@update');
Route::delete('/user/{id}', 'UserController@destroy');

Route::get('/login', 'LoginController@index');
Route::post('/login', 'LoginController@logMeIn');

Route::get('/logout', 'LoginController@logOut');

// Route::get('/user', 'UserController@index');
