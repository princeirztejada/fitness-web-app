<?php

namespace FitnessApp\Http\Controllers;

use Illuminate\Http\Request;
use FitnessApp\User;
use DB;

class LoginController extends Controller
{
    public function index(){
        return redirect('/#login');
    }

    public function logMeIn(Request $request){
        $this->validate($request, [
            'emailAddress' => 'required',
            'psswrd' => 'required'
        ]);

        $user = new User;
        $users = $user->checkIfUserExist($request->emailAddress, $request->psswrd);

        if ( count($users) > 0 ) {

            $data = json_decode($users->toJson(),true);

            $request->session()->put('user', $data[0]['lastName'] . ", " . $data[0]['firstName']);
            $request->session()->put('id', $data[0]['id']);
            $request->session()->put('firstName', $data[0]['firstName']);
            $request->session()->put('lastName', $data[0]['lastName']);
            $request->session()->put('email', $data[0]['email']);
            $request->session()->put('password', $data[0]['password']);
            $request->session()->put('isAdmin', $data[0]['isAdmin']);
            return redirect('/');
        } else {
            return redirect('/#login')->with('error', 'No user credentials found!');
        }
    }

    public function logOut(Request $request){
        $request->session()->flush();
        return redirect('/');
    }
}
