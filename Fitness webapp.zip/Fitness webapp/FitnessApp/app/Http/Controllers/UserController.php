<?php

namespace FitnessApp\Http\Controllers;

use Illuminate\Http\Request;
use FitnessApp\User;
use DB;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(!session()->has('user'))
            return redirect('/');
        $user = new User;

        $users = $user->getUserList();

        return view('users')->with('users',$users);
    }

    public function store(Request $request)
    {
        $this->validate($request, [
            'firstName' => 'required',
            'lastName' => 'required',
            'emailAddress' => 'required',
            'psswrd' => 'required',
            'psswrdCnfrm' => 'required',
        ]);

        $user = new User;
        
        if ( $request->input('psswrd') == $request->input('psswrdCnfrm') ) {
            $user->firstName = $request->input('firstName');
            $user->lastName = $request->input('lastName');
            $user->email = $request->input('emailAddress');
            $user->password = $request->input('psswrd');
            $user->save();
            if (url()->previous() == "http://127.0.0.1:8000/") 
                return redirect('/#login')->with('success', 'Registered Succesfully');
            else
                return redirect('/user')->with('success', 'Registered Succesfully');
        } else {
            return redirect('/#login')->with('error', 'Error Registering!');
        }
    }


    public function myProfile(Request $request){
        return view('profile');
    }




    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $this->validate($request, [
            'firstName' => 'required',
            'lastName' => 'required',
            'psswrd' => 'required'
        ]);

        $user = new User;
        if ( $request->psswrd == $request->session()->get('password')) {
            
        $users = $user->getLoggedInUser($request->session()->get('email'), $request->psswrd);
        // var_dump($users->toJson());
        if ( count($users) > 0 ) {
            $result = $user->updateUser($request->session()->get('id'),$request->firstName,$request->lastName);
            
            if ($result) {
                $request->session()->put('user', $request->lastName . ", " . $request->firstName);
                $request->session()->put('firstName', $request->firstName);
                $request->session()->put('lastName', $request->lastName);
                return redirect('/myProfile')->with('success', "Success Updating!");
            }
        } else {
            return redirect('/#login')->with('error', 'No user credentials found!');
        }
    } else {
        return redirect('/myProfile')->with('error', 'Wrong Password!');
     }
    }
    

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $user = new User;

        $result = $user->deleteUser($id);
        
        return $result;
    }

}
