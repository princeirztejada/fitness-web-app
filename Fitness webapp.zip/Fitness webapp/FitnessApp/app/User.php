<?php

namespace FitnessApp;

use Illuminate\Database\Eloquent\Model;

class User extends Model
{
    protected $table = "users";

    public $primaryKey = 'id';

    public function checkIfUserExist($email,$psswrd) {
        return User::where([
            ['email', '=', $email],
            ['password', '=', $psswrd]
        ])->get();
    }

    public function getUserList(){
        return User::where('isAdmin', '0')->get();
    }

    public function getLoggedInUser($email, $psswrd) {
        return User::where([
            ['email', '=',$email],
            ['password', '=', $psswrd]])->get();
    }

    public function updateUser($id,$firstName,$lastName){
        return User::where('id', $id)->update(['firstName' => $firstName , 'lastName' => $lastName]);
    }

    public function deleteUser($id){
        return User::where('id','=',$id)->delete();
    }
    
}
