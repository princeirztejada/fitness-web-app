<?php $__env->startSection('content'); ?>
<section>

    <section class="contact">
        <div class="container">
           <?php echo $__env->make('includes.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
           <div class="content" style="min-width: 70vw">
            <center>
               <div class="box form wow slideInLeft" style="text-align: left; position: relative; min-width: 50%; max-width: 50%;" >
                   <h2 style="color: white;">My Profile</h2> <br>
                      <?php echo Form::open(['action' => 'UserController@update', 'method' => 'PATCH']); ?>

                          <?php echo e(Form::label('firstName', 'First Name',['style' => 'color: white;'])); ?>

                       <?php echo e(Form::text('firstName', Session::get('firstName'), ['required','placeholder' =>  Session::get('firstName') ])); ?>

                       <?php echo e(Form::label('lastName', 'Last Name',['style' => 'color: white;'])); ?>

                       <?php echo e(Form::text('lastName', Session::get('lastName'), ['required','placeholder' => Session::get('lastName')])); ?>

                       <?php echo e(Form::label('', 'Email Address',['style' => 'color: white;'])); ?>

                       <?php echo e(Form::email('', Session::get('email'), ['disabled','placeholder' => Session::get('email')])); ?>

                       <?php echo e(Form::label('psswrd', 'Enter Password',['style' => 'color: white;'])); ?>

                       <?php echo e(Form::password('psswrd', ['required','id'=>'psswrd','placeholder' => "Enter Password"])); ?>

                       <?php echo e(Form::button("Save Edit", ['id'=>'signbtn','type' => "submit"])); ?>

                     <?php echo Form::close(); ?>

               </div>
            </center>
           </div>
        </div>
     </section>

</section>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>