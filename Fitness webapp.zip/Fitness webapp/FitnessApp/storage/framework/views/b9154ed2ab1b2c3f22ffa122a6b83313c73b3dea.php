<?php $__env->startSection('content'); ?>
<section>
    <section class="contact" style='background-color: white;'>
        <div class="container">
        <h2 style="margin-top: 5vh;"> User List </h2><br>
           <?php echo $__env->make('includes.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
           <table id="userTable" class="display">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Created At</th>
                    <th>Updated At</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
           <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($user->id); ?> </td>
                    <td> <?php echo e($user->firstName); ?> </td>
                    <td> <?php echo e($user->lastName); ?> </td>
                    <td> <?php echo e($user->email); ?> </td>
                    <td> <?php echo e($user->created_at); ?> </td>
                    <td> <?php echo e($user->updated_at); ?> </td>
                    <td>
                        <i style="font-size: 2em;" class="fa fa-trash" onclick="deleteUser(<?php echo e($user->id); ?>)"></i>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        </div>
     </section>

</section>

<script>
    function deleteUser(id) {
        $.ajax({
            url: '/user/'+id,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            method: 'DELETE',
            success: function(result) { 
                if (result){
                    alert("Success deleting");
                    location.reload();
                }
                else {
                    alert("Error deleting");
                }
            }
        });
    }
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>