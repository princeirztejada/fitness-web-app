<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">
<head>
	<title><?php echo e(config('app.name','Fitness Club')); ?></title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/animate.css">
  <link rel="stylesheet" href="css/style.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
	<link href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.min.css" rel="stylesheet">
<script src="https://use.fontawesome.com/ee471f5f5f.js"></script>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  <style>
    .wow:first-child {
      visibility: hidden;
    }
  </style>
  
</head>
<body>
 
 <!-- Start Header  -->
 <header>
 	 <div class="container">
 	 	<div class="logo">
 	 		 <a href=""><?php echo e(config('app.name','Fitness Club')); ?></a>
 	 	</div>
 	 	<a href="javascript:void(0)" class="ham-burger">
 	       <span></span>	
 	       <span></span>
 	 	</a>
 	 	<div class="nav">
            <ul>
              <?php if( URL::current() == "http://127.0.0.1:8000"): ?>
 	 			<li><a href="#home">Home </a></li>
 	 			<li><a href="#about">About</a></li>
 	 			<li><a href="#service">Services</a></li>
 	 			<li><a href="#classes">Classes</a></li>
 	 			<li><a href="#schedule">Schedule</a></li>
 	 			<li><a href="#price">Price</a></li>
              <?php else: ?>
                <li><a href="/">Home</a></li>
              <?php endif; ?>
              <?php if(Session::has('user')): ?>
			  	<li><a href="/myProfile"> <?php echo e(Session::get('user')); ?> </a></li>
			  <?php if(Session::get('isAdmin') == "1"): ?>
			  	<li><a href="/user"> User List </a></li>
			  <?php endif; ?>
			  	<li><a href="/logout">Log out</a></li>
			  <?php elseif(!Session::has('user')): ?>
			  	<li><a href="#login"> Sign up / Login</a></li>
			  <?php endif; ?>
          </ul>
 	 	</div>
 	 </div>
 </header>
 
 <?php echo $__env->yieldContent('content'); ?>