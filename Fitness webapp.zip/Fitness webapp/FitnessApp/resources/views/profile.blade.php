@extends('includes.header')

@section('content')



<section>

    <section class="contact">
        <div class="container">
           @include('includes.alerts')
           <div class="content" style="min-width: 70vw">
            <center>
               <div class="box form wow slideInLeft" style="text-align: left; position: relative; min-width: 50%; max-width: 50%;" >
                   <h2 style="color: white;">My Profile</h2> <br>
                      {!! Form::open(['action' => 'UserController@update', 'method' => 'PATCH']) !!}
                          {{Form::label('firstName', 'First Name',['style' => 'color: white;'])}}
                       {{Form::text('firstName', Session::get('firstName'), ['required','placeholder' =>  Session::get('firstName') ])}}
                       {{Form::label('lastName', 'Last Name',['style' => 'color: white;'])}}
                       {{Form::text('lastName', Session::get('lastName'), ['required','placeholder' => Session::get('lastName')])}}
                       {{Form::label('', 'Email Address',['style' => 'color: white;'])}}
                       {{Form::email('', Session::get('email'), ['disabled','placeholder' => Session::get('email')])}}
                       {{Form::label('psswrd', 'Enter Password',['style' => 'color: white;'])}}
                       {{Form::password('psswrd', ['required','id'=>'psswrd','placeholder' => "Enter Password"])}}
                       {{Form::button("Save Edit", ['id'=>'signbtn','type' => "submit"])}}
                     {!! Form::close() !!}
               </div>
            </center>
           </div>
        </div>
     </section>

</section>

@endsection


@include('includes.footer')
