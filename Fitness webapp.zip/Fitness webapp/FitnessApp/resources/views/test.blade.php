@extends('includes.header')

{{config('app.name' , 'test')}}
