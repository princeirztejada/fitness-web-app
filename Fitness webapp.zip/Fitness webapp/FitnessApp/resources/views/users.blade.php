@extends('includes.header')

@section('content')


<section>
    <section class="contact" style='background-color: white;'>
        <div class="container">

        <!-- The Modal -->
        <div id="myModal" class="modal-parent">

        <!-- Modal content -->
        <div class="modal-body">
            <span class="close">&times;</span>
            <div class="content">
                <center>
                    <div class="box form wow">
                        <h2 style="color: black;">Add User</h2>
                    <!-- <form> -->
                        {!! Form::open(['action' => 'UserController@store', 'method' => 'POST', 'style' => 'color: black;']) !!}
                            {{Form::label('firstName', 'First Name')}}
                            {{Form::text('firstName', '', ['required','placeholder' => "Enter First Name", 'style' => 'color: black; border: 1px solid black;'])}}
                            {{Form::label('lastName', 'Last Name')}}
                            {{Form::text('lastName', '', ['required','placeholder' => "Enter Last Name", 'style' => 'color: black; border: 1px solid black;'])}}
                            {{Form::label('emailAddress', 'Email Address')}}
                            {{Form::email('emailAddress', '', ['required','placeholder' => "Enter Email Address", 'style' => 'color: black; border: 1px solid black;'])}}
                            {{Form::label('psswrd', 'Enter Password')}}
                            {{Form::password('psswrd', ['required','id'=>'psswrd','placeholder' => "Enter Password", 'onKeyUp' => "checkPassword()", 'style' => 'color: black; border: 1px solid black;'])}}
                            {{Form::label('psswrdCnfrm', 'Confirm Password')}}
                            {{Form::password('psswrdCnfrm', ['required','id'=>'psswrdCnfrm','placeholder' => "Confirm Password", 'onKeyUp' => "checkPassword()", 'style' => 'color: black; border: 1px solid black;'])}}
                            <span id="passError" hidden> Passwords do not match! </span>
                            {{Form::button("Add User", ['id'=>'signbtn','type' => "submit"])}}
                        {!! Form::close() !!}
                    <!-- </form> -->
                    </div>
                </center>
            </div>
        </div>

        </div>  
        <ul id="profNav" style="list-style: none;">
        <li> <span style="font-size: 2em; font-weight: 600;">User List </span></li>
            <li><button class="btn btn-secondary" id="myBtn">Add User</button></li>
        </ul>
           @include('includes.alerts')
           <table id="userTable" class="display">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Created At</th>
                    <th>Updated At</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
           @foreach($users as $user)
                <tr id="{{$user->id}}">
                    <td> {{$user->id}} </td>
                    <td> {{$user->firstName}} </td>
                    <td> {{$user->lastName}} </td>
                    <td> {{$user->email}} </td>
                    <td> {{$user->created_at}} </td>
                    <td> {{$user->updated_at}} </td>
                    <td>
                        <i style="font-size: 2em;" class="fa fa-trash" onclick="deleteUser({{$user->id}})"></i>
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
        </div>
     </section>

</section>

<script>

    var modal = document.getElementById("myModal");

    // Get the button that opens the modal
    var btn = document.getElementById("myBtn");

    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];

    // When the user clicks on the button, open the modal
    btn.onclick = function() {
    modal.style.display = "block";
    }

    // When the user clicks on <span> (x), close the modal
    span.onclick = function() {
    modal.style.display = "none";
    }

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
    }

    function deleteUser(id) {
        $.ajax({
            url: '/user/'+id,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            method: 'DELETE',
            success: function(result) { 
                if (result){
                    alert("Success deleting");
                    $('#'+id).remove();
                }
                else {
                    alert("Error deleting");
                }
            }
        });
    }
    </script>

@endsection


@include('includes.footer')
